from pathlib import Path
import pandas as pd

# 1) Caminho 100% seguro para o arquivo ao lado do .py
BASE = Path(__file__).resolve().parent
csv_path = BASE / "StressLevelDataset.csv"

print("Lendo de:", csv_path)
if not csv_path.exists():
    raise FileNotFoundError("CSV não encontrado nesse caminho. Verifique o nome e a pasta.")

# 2) Tenta UTF-8; se falhar, tenta latin1 (muito comum em arquivos do Windows/Excel)
read_opts = dict(encoding="utf-8-sig")
try:
    df = pd.read_csv(csv_path, **read_opts)
except UnicodeDecodeError:
    read_opts["encoding"] = "latin1"
    df = pd.read_csv(csv_path, **read_opts)

# 3) Se o arquivo estiver separado por ';' (padrão BR), relê com sep=';'
#    Heurística simples: se veio tudo numa coluna só, tente com ';'
if df.shape[1] == 1:
    df = pd.read_csv(csv_path, sep=";", decimal=",", **read_opts)

# Exibição
pd.set_option("display.max_columns", None)
pd.set_option("display.width", 0)

print("Shape:", df.shape)
print("Colunas:", df.columns.tolist())
print(df.head(1101))